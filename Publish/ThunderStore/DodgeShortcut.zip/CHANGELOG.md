<table>
	<tbody>
		<tr>
			<th align="center">Version</th>
			<th align="center">Notes</th>
		</tr>
		<tr>
			<td align="center">1.1.0</td>
			<td align="left">
				<ul>
					<li>Added option to configure default dodge direction when standing still.</li>
					<li>Updated icon and README.</li>
					<li>Recompiled against newest Valheim version.</li>
				</ul>
			</td>
		</tr>
		<tr>
			<td align="center">1.0.7</td>
			<td align="left">
				<ul>
					<li>Maintenance update.</li>
					<li>Improved shutdown performance.</li>
				</ul>
			</td>
		</tr>
		<tr>
			<td align="center">1.0.6</td>
			<td align="left">
				<ul>
					<li>Updated for patch 0.217.25.</li>
				</ul>
			</td>
		</tr>
		<tr>
			<td align="center">1.0.3 - 1.0.5</td>
			<td align="left">
				<ul>
					<li>Updated README (Spelling is hard and Thunderstore won't let you edit the README without uploading a new version).
					<li>Fixed BepInEx mod ID</li>
				</ul>
			</td>
		</tr>
		<tr>
			<td align="center">1.0.2</td>
			<td align="left">
				<ul>
					<li>Updated for patch 0.217.22.</li>
				</ul>
			</td>
		</tr>
		<tr>
			<td align="center">1.0.1</td>
			<td align="left">
				<ul>
					<li>Fixed Github link in manifest.</li>
				</ul>
			</td>
		</tr>
		<tr>
			<td align="center">1.0.0</td>
			<td align="left">
				<ul>
					<li>Initial release.</li>
				</ul>
			</td>
		</tr>
	</tbody>
</table>
